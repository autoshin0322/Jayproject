Thema:
  ZIP-Verfahren
  |_ Algorithmen
     |_ Lempel Ziv
     |_ LZ77
     |_ LZ78
     |_ Lempel Ziv Welch

Name der Studierende:
  -Loukas Melissopoulos
  -Bilal Boui
  -Mimoun El Masiani

Wenn Sie PyCharm oder eine ähnliche Python Entwicklungsumgebung besitzen
können Sie den Ordner „LempelZiv“ importieren dies das Python-Projekt ist
mit allen programmierabhängigkeiten.

Ansonsten können Sie in jeder anderen Python-Entwicklungsumgebung die Datein
aufrufen. Diese befinden sich im Ordner „python_files“.

Sobald diese in ihr eigenes Python-Projekt hinzugefügt worden sind, führen Sie
die „Application.py“ Datei als erstes aus. Diese ist die Hauptführende Datei.
Die anderen sollten aber auch einzeln laufen.

Falls Sie weitere Informationen oder Hilfe brauchen, können Sie uns kontaktieren:
  -entweder unter der E-Mail die wir benutzt haben diesen ZIP-Ordner zu schicken
  -oder unter: loukas.melissopoulos@yahoo.com